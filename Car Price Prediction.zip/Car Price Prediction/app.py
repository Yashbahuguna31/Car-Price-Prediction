import streamlit as st
import pickle
import numpy as np
import pandas as pd

# Load the transformation model
with open('preprocessor.pkl', 'rb') as file:
    preprocessor = pickle.load(file)

# Load the prediction model
with open('model.pkl', 'rb') as file:
    model = pickle.load(file)

# Load the transformation model
with open('label_encoder.pkl', 'rb') as file:
    label_encoder = pickle.load(file)


# Streamlit app
st.title('Car Price Prediction')

# Collect input features from the user
st.write("Enter the features:")

kilometer_driven = st.number_input('Kilometer driven', value=0.0)
fuel_type = st.text_input('Fuel')
seller = st.text_input('Seller Type')
transmission_type = st.text_input('Transmission Type')
owner_type = st.text_input('Owner Type')
mileage_value = st.number_input('Mileage', value=0.0)
engine_value  = st.number_input('Engine', value=0.0)
max_power_value = st.number_input('Max Powerr', value=0.0)
torque_value = st.number_input('Torque', value=0.0)
seats_value = st.text_input('Seats')

# Dropdown for categorical feature
text_feature_options = ['Swift-Dzire', 'Rapid', 'City', 'i20', 'Swift', 'Xcent', 'Wagon-R', '800', 'Etios', 'Figo', 'Duster',
                        'Zen', 'KUV', 'Ertiga', 'Alto', 'Verito', 'WR-V', 'SX4', 'Tigor', 'Baleno', 'Enjoy', 'Omni', 'Vitara', 
                        'Verna', 'GO', 'Safari', 'Compass', 'Fortuner', 'Innova', 'B-Class', 'Amaze', 'Ciaz', 'Jazz', 'A6', 
                        'Corolla', 'C-Class', 'Manza', 'i10', 'Ameo', 'Vento', 'EcoSport', 'X1', 'Celerio', 'Polo', 'Eeco', 
                        'Scorpio', 'Freestyle', 'Passat', 'Indica', 'XUV500', 'Indigo', 'Terrano', 'Creta', 'KWID', 'Santro', 
                        'Q5', 'ES', 'XF', 'Wrangler', 'S-Class', '5-Series', 'X4', 'Superb', 'E-Class', 'XC40', 'Q7', 'Elantra', 
                        'XE', 'Nexon', 'Glanza', '3-Series', 'Camry', 'Ritz', 'Grand', 'Zest', 'Getz', 'Elite', 'Brio', 'Hexa', 
                        'Sunny', 'Micra', 'Ssangyong', 'Quanto', 'Accent', 'Ignis', 'Marazzo', 'Tiago', 'Thar', 'Sumo', 'New', 
                        'Bolero', 'GL-Class', 'Beat', 'A-Star', 'XUV300', 'Nano', 'V40', 'CR-V', 'EON', 'RediGO', 'Captiva', 
                        'Fiesta', 'Civic', 'Sail', 'Venture', 'Classic', 'BR-V', 'Ecosport', 'Aria', 'TUV', 'Bolt', 'Accord', 
                        'Xylo', 'Grande', 'S-Cross', 'Yaris', 'Tavera', 'Linea', 'Endeavour', 'Aveo', 'Triber', 'Octavia', 
                        'A4', 'Santa', 'Spark', 'Aspire', 'Optra', 'Mobilio', 'BRV', 'Cruze', 'GLA', '6-Series', 'NuvoSport', 
                        'Lodgy', 'Pulse', 'Sonata', 'Renault', 'Kicks', 'Jetta', 'M-Class', 'Q3', 'Ikon', 'Fluence', 'Fabia', 
                        'Platinum', 'Captur', 'Gypsy', 'Harrier', 'Punto', 'Avventura', 'Esteem', 'Qualis', 'Estilo', 'Jeep']

car_name = st.selectbox('model', options=text_feature_options)
year_used = st.number_input('number_of_year_used', value=0.0)

if st.button('Predict'):
    try:
        input_features = pd.DataFrame({
                                        'km_driven': [kilometer_driven],
                                        'fuel': [fuel_type],
                                        'seller_type': [seller],
                                        'transmission': [transmission_type],
                                        'owner': [owner_type],
                                        'mileage': [mileage_value],
                                        'engine': [engine_value],
                                        'max_power': [max_power_value],
                                        'torque': [torque_value],
                                        'seats': [seats_value],
                                        'model': [car_name],
                                        'number_of_year_used': [year_used]
                                    })

        # Labelencode the model variable 
        input_features['model'] = label_encoder.transform(input_features['model'])
        
        # Transform the input features
        transformed_features = preprocessor.transform(input_features)

        # Make predictions
        prediction = model.predict(transformed_features)

        # Display the prediction
        st.write(f'Prediction: {prediction[0]}')
    except ValueError:
        st.write('Error: Please enter valid inputs.')